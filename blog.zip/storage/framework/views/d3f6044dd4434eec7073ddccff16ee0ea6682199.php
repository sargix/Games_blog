

<?php $__env->startSection('content'); ?>
<div class="container pt-3"></div>
<?php if(!empty($message)): ?>
<div class="alert alert-primary">
    <?php echo e($message); ?>

  </div>
<?php endif; ?>
<div class="container pt-3"></div>
<h1>Lista gier</h1>
    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container pt-3"></div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Nr: <?php echo e($loop->iteration); ?>.</h4>
                        <h2 class="card-title">Tytuł: <?php echo e($game->title); ?></h2>
                        <h5 class="card-title">Platformy: <?php echo e($game->platform); ?></h5>
                        <h5 class="card-title">Data wydania: <?php echo e($game->publicate_date); ?></h5>
                        <a href="<?php echo e(route('game.edit.form', $game->id)); ?>" class="btn btn-dark">Edytuj</a>
                        <a href="<?php echo e(route('game.show', $game->id)); ?>" class="btn btn-info">Zobacz</a>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal<?php echo e($game->id); ?>">
                            Usuń 
                          </button>
                    </div>
                </div>
            </div>
        </div>
          <div class="modal" id="myModal<?php echo e($game->id); ?>">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Usuń wpis</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    Czy na pewno chcesz usunąć ten wpis?
                </div>
                <div class="modal-footer">
                  <a href="<?php echo e(route('game.delete', $game->id)); ?>" class="card-link">Usuń</a>
                </div>
              </div>
            </div>
          </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\damian\Desktop\Projekty_stron\games_blog\resources\views/blog/list.blade.php ENDPATH**/ ?>