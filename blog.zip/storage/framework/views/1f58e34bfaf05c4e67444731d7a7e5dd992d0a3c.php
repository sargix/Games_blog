

<?php $__env->startSection('content'); ?>
    <div class="container pt-3"></div>
    <h1><?php echo e($game[0]->title); ?></h1>
    <div class="container pt-3"></div>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Identyfikator: <?php echo e($game[0]->id); ?>.</h4>
            <h2 class="card-title">Tytuł: <?php echo e($game[0]->title); ?></h2>
            <h5 class="card-title">Gatunek: <?php echo e($game[0]->genre_name); ?></h5>
            <h5 class="card-title">Wydawca: <?php echo e($game[0]->publisher_name); ?></h5>
            <h5 class="card-title">Platformy: <?php echo e($game[0]->platform); ?></h5>
            <h5 class="card-title">Data wydania: <?php echo e($game[0]->publicate_date); ?></h5>
            <p class="card-text">Opis: <?php echo e($game[0]->description); ?></p>
            <a href="<?php echo e(route('games.list')); ?>" class="btn btn-dark">Powrót</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\damian\Desktop\Projekty_stron\games_blog\resources\views/blog/show.blade.php ENDPATH**/ ?>