<div class="container pt-4"></div>
  <footer class="bg-light text-center text-lg-start">
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.6);">
        Games World 2021 &copy; 
      </div>
  </footer>